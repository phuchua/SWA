package stock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootReactiveStockApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootReactiveStockApplication.class, args);
	}
}
