package service;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	@GetMapping("/name")
	public String getName() {
		return "Userx";
	}
	
	@GetMapping("/phone")
	public String getPhone() {
		return "641111112";
	}

}
