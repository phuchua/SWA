package kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.github.javafaker.Faker;

@Component
public class SpeedMappingWithOwnNameAndFee {
	@Autowired
	Sender sender;
	
    @Value("${app.topic.ownertopic}")
    private String owntopic;
	
		
	public void handleRecord(SpeedRecord speedRecord) {
		String name = getNameByLicencePlate(speedRecord.licencePlate);
		int fee = calculatePenaltyFee(speedRecord);
		System.out.println("Over speed limit with name ********="+ name);
		sender.send(owntopic, new FeeRecord(speedRecord.licencePlate, name, fee));		
	}


	private String getNameByLicencePlate(String licencePlate) { //generate dummy name
		Faker faker = new Faker();
		String name = faker.name().fullName();
		
		return name;
	}
	
	private int calculatePenaltyFee(SpeedRecord speedRecord) {		
			int result;
			if (isBetween(speedRecord.speed, 72, 77)) {
				result = 25;
			} else if (isBetween(speedRecord.speed, 78, 82)) {
				result = 45;
			}else if (isBetween(speedRecord.speed, 83, 90)) {
				result = 80;
			}else {
				result = 125;
			}
			
			return result;
	}
	
	public static boolean isBetween(int x, int lower, int upper) {
		  return lower <= x && x <= upper;
		}
}
