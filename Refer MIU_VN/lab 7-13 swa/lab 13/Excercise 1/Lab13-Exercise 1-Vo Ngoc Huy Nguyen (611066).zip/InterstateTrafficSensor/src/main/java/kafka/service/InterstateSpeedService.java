package kafka.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import kafka.SensorRecord;
import kafka.SpeedCalculator;
import kafka.SpeedRecord;

@Service
public class InterstateSpeedService {

	@Autowired
	SpeedCalculator speedCalculator;
	
    @KafkaListener(topics = {"${app.topic.cameratopic1}" , "${app.topic.cameratopic2}"})
    public void receive(@Payload SensorRecord SensorRecord,
                        @Headers MessageHeaders headers) {
        //System.out.println("--> received message="+ SensorRecord.toString());
    	speedCalculator.handleRecord(SensorRecord);
    }


    /*
    @KafkaListener(topics = {"${app.topic.tofasttopic}"})
    public void receive(@Payload SpeedRecord speedRecord,
                        @Headers MessageHeaders headers) {
        System.out.println("--> received message="+ speedRecord.toString());
    }
    */

}