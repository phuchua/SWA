package kafka.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import kafka.FeeRecord;
import kafka.SpeedMappingWithOwnNameAndFee;
import kafka.SpeedRecord;

@Service
public class OwnService {

	@Autowired
	SpeedMappingWithOwnNameAndFee speedMappingWithOwnName;
	
    @KafkaListener(topics = {"${app.topic.tofasttopic}"})
    public void receive(@Payload SpeedRecord speedRecord,
                        @Headers MessageHeaders headers) {        
        speedMappingWithOwnName.handleRecord(speedRecord);
    }
    
   /*
    @KafkaListener(topics = {"${app.topic.ownertopic}"})
    public void receive(@Payload FeeRecord feeRecord,
                        @Headers MessageHeaders headers) {
        System.out.println("--> received message="+ feeRecord.toString());
    }
	*/
}