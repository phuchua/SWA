package kafka.service;



import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import kafka.FeeRecord;


@Service
public class FeeCalculatorService {

  
    @KafkaListener(topics = {"${app.topic.ownertopic}"})
    public void receive(@Payload FeeRecord feeRecord,
                        @Headers MessageHeaders headers) {
        System.out.println("--> received message="+ feeRecord.toString());
    }

}