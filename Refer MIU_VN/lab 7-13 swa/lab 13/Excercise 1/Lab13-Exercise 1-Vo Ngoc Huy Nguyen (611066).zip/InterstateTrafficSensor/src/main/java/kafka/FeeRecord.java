package kafka;


public class FeeRecord {
	public String licencePlate;
	public String name;
	public int fee;
	
	public FeeRecord(String licencePlate, String name, int fee) {
		super();
		this.licencePlate = licencePlate;
		this.name = name;
		this.fee = fee;
	}
	
	public FeeRecord() {}

	public String getLicencePlate() {
		return licencePlate;
	}

	public void setLicencePlate(String licencePlate) {
		this.licencePlate = licencePlate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getFee() {
		return fee;
	}

	public void setFee(int fee) {
		this.fee = fee;
	}

	@Override
	public String toString() {
		return "FeeRecord [licencePlate=" + licencePlate + ", name=" + name + ", fee=" + fee + "]";
	}


	
}
