package shop;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class ServiceCController {

	
	@RequestMapping("/text")
	public String getText() {
		return "World from ServiceC";
	}
	
	
	
}
