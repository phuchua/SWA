package shop;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("shop")
@SpringBootApplication
//@EnableDiscoveryClient
public class ServiceCApplication  {

	public static void main(String[] args) {
		SpringApplication.run(ServiceCApplication.class, args);
	}

	/*
	@Bean
	RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		return restTemplate;
	}
	*/
}
