package com.controller;

import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.domain.Account;

@RestController
@Profile("One")
public class AccountController1 {
	@GetMapping("/account/{customerid}")
	public Account getName(@PathVariable("customerid") String customerId) {
		System.out.println("getName() on AccountController1 is called");
		return new Account("1234", "1000.00");
	}


}
