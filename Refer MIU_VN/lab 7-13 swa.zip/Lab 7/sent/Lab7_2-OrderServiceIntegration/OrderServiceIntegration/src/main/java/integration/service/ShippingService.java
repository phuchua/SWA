package integration.service;


public class ShippingService {
	public void printShipping() throws Exception {
        System.out.println("--- In Shipping service");

    }
}
