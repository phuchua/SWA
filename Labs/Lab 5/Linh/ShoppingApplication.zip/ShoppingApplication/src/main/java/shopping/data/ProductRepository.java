package shopping.data;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;
import shopping.domain.Product;

import java.util.List;

@Repository
public interface ProductRepository extends MongoRepository<Product,Integer>{
    //private List<Product> products = new ArrayList<>();

    List<Product> findAll();


    @Override
    <S extends Product> S insert(S entity);

    @Query("{'productNumber' : ?0}")
    Product findProductByNumber(String productNumber);

}
