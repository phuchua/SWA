package shopping.domain;

import org.springframework.data.mongodb.core.mapping.Document;
@Document
public class Product {

    private String productNumber;
    private String description;
    private Double price;
    private Supplier supplier;

    public Product() {

    }

    public Product(String productNumber, String description, Double price, Supplier supplier) {

        this.productNumber = productNumber;
        this.description = description;
        this.price = price;
        this.supplier = supplier;
    }


    public String getProductNumber() {
        return productNumber;
    }

    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    @Override
    public String toString() {
        return "Product{" +
                ", productNumber='" + productNumber + '\'' +
                ", description='" + description + '\'' +
                ", price=" + price +
                ", supplier=" + supplier +
                '}';
    }
}
