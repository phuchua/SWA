package shopping.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import shopping.domain.Product;
import shopping.service.ProductService;

import java.util.Collection;

@RestController
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping("/products")
    public ResponseEntity<?> getAllProducts() {
        Collection<Product> allProducts = productService.getAllProduct();
        return new ResponseEntity<>(allProducts, HttpStatus.OK);
    }

    @GetMapping("/products/{prodNumber}")
    public ResponseEntity<?>getProduct(@PathVariable String prodNumber){
        Product product = productService.getProduct(prodNumber);
        if(product == null){
            return new ResponseEntity<>(new CustomErrorType("Product with productNumber= "
                    + prodNumber + " is not available"), HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(product, HttpStatus.OK);

    }
    @PostMapping("/products")
    public ResponseEntity<?> addProduct(@RequestBody Product product) {
        productService.addProduct(product);
        return new ResponseEntity<>(product, HttpStatus.OK);
    }
}
