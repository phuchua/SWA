package shoppings;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class RestClientApplication implements CommandLineRunner {
	@Autowired
	private RestOperations restTemplate;

	public static void main(String[] args) {
		SpringApplication.run(RestClientApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		String serverUrl = "http://localhost:8081/products";

		// add Product 1
		restTemplate.postForLocation(serverUrl, new Product("abc124","desc1",19.4,
				new Supplier("aS1","s1","702-191-1912","s1@gmail.com",new Address("st1","Dallas",18191,"US"))));
		// add Product 2
		restTemplate.postForLocation(serverUrl, new Product("abc123","desc2",18.1,
				new Supplier("aS2","s2","702-191-1912","s2@gmail.com",new Address("st2","Dallas",91814,"US"))));
		// get Book 1
		Product product= restTemplate.getForObject(serverUrl+"/{prodNumber}", Product.class, "abc124");
		System.out.println("----------- get product 1-----------------------");
		System.out.println(product.toString());

	}


	@Bean
	RestOperations restTemplate()
	{
		return new RestTemplate();
	}
}
