package esb;

public enum OrderType {
    International,
    Domestic
}
